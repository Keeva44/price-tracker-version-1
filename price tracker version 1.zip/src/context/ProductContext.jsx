import React, { createContext, useState, useEffect } from 'react';
import Papa from 'papaparse';

export const ProductContext = createContext();

// Enhanced mock data with store inventory and reviews
const mockProducts = [
  {
    id: '1',
    name: 'Apple iPhone 15 Pro Max 256GB',
    url: 'https://amazon.com/iphone-15-pro-max',
    brand: 'Apple',
    category: 'Electronics',
    description: 'Latest iPhone with A17 Pro chip, titanium design, and advanced camera system',
    stores: {
      'Amazon': { 
        price: 1199.99, 
        originalPrice: 1299.99, 
        availability: 'In Stock', 
        quantity: 15,
        seller: 'Amazon',
        shipping: 'Free 2-day shipping',
        lastUpdated: new Date().toISOString()
      },
      'Best Buy': { 
        price: 1249.99, 
        originalPrice: 1299.99, 
        availability: 'Limited Stock', 
        quantity: 3,
        seller: 'Best Buy',
        shipping: 'Free store pickup',
        lastUpdated: new Date(Date.now() - 1000 * 60 * 15).toISOString()
      },
      'Apple Store': { 
        price: 1299.99, 
        originalPrice: 1299.99, 
        availability: 'In Stock', 
        quantity: 25,
        seller: 'Apple',
        shipping: 'Free shipping',
        lastUpdated: new Date(Date.now() - 1000 * 60 * 30).toISOString()
      },
      'Target': { 
        price: 0, 
        originalPrice: 1299.99, 
        availability: 'Out of Stock', 
        quantity: 0,
        seller: 'Target',
        shipping: 'N/A',
        lastUpdated: new Date(Date.now() - 1000 * 60 * 45).toISOString()
      }
    },
    reviews: {
      rating: 4.8,
      totalReviews: 12547,
      breakdown: { 5: 9821, 4: 1876, 3: 542, 2: 201, 1: 107 }
    },
    priceHistory: [
      { date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7).toISOString(), price: 1299.99 },
      { date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString(), price: 1249.99 },
      { date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString(), price: 1199.99 },
      { date: new Date().toISOString(), price: 1199.99 }
    ],
    alerts: {
      priceTarget: 1150.00,
      stockAlert: true,
      priceDropAlert: true
    },
    image: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=300&h=300&fit=crop',
    dateAdded: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10).toISOString()
  },
  {
    id: '2',
    name: 'Sony WH-1000XM5 Wireless Headphones',
    url: 'https://bestbuy.com/sony-headphones',
    brand: 'Sony',
    category: 'Audio',
    description: 'Industry-leading noise canceling headphones with 30-hour battery life',
    stores: {
      'Amazon': { 
        price: 349.99, 
        originalPrice: 399.99, 
        availability: 'In Stock', 
        quantity: 42,
        seller: 'Sony Direct',
        shipping: 'Free shipping',
        lastUpdated: new Date().toISOString()
      },
      'Best Buy': { 
        price: 379.99, 
        originalPrice: 399.99, 
        availability: 'In Stock', 
        quantity: 8,
        seller: 'Best Buy',
        shipping: 'Free store pickup',
        lastUpdated: new Date(Date.now() - 1000 * 60 * 20).toISOString()
      },
      'Target': { 
        price: 389.99, 
        originalPrice: 399.99, 
        availability: 'Limited Stock', 
        quantity: 2,
        seller: 'Target',
        shipping: '$5.99 shipping',
        lastUpdated: new Date(Date.now() - 1000 * 60 * 35).toISOString()
      }
    },
    reviews: {
      rating: 4.6,
      totalReviews: 8934,
      breakdown: { 5: 6247, 4: 1789, 3: 623, 2: 201, 1: 74 }
    },
    priceHistory: [
      { date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 14).toISOString(), price: 399.99 },
      { date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7).toISOString(), price: 379.99 },
      { date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(), price: 349.99 }
    ],
    alerts: {
      priceTarget: 320.00,
      stockAlert: true,
      priceDropAlert: true
    },
    image: 'https://images.unsplash.com/photo-1583394838336-acd977736f90?w=300&h=300&fit=crop',
    dateAdded: new Date(Date.now() - 1000 * 60 * 60 * 24 * 20).toISOString()
  },
  {
    id: '3',
    name: 'Samsung 65" QLED 4K Smart TV',
    url: 'https://target.com/samsung-tv',
    brand: 'Samsung',
    category: 'Electronics',
    description: '65-inch QLED 4K Smart TV with Quantum HDR and Alexa Built-in',
    stores: {
      'Amazon': { 
        price: 1299.99, 
        originalPrice: 1199.99, 
        availability: 'In Stock', 
        quantity: 12,
        seller: 'Samsung',
        shipping: 'Free shipping + installation',
        lastUpdated: new Date().toISOString()
      },
      'Best Buy': { 
        price: 1249.99, 
        originalPrice: 1199.99, 
        availability: 'In Stock', 
        quantity: 6,
        seller: 'Best Buy',
        shipping: 'Free delivery + setup',
        lastUpdated: new Date(Date.now() - 1000 * 60 * 10).toISOString()
      },
      'Walmart': { 
        price: 0, 
        originalPrice: 1199.99, 
        availability: 'Out of Stock', 
        quantity: 0,
        seller: 'Walmart',
        shipping: 'N/A',
        lastUpdated: new Date(Date.now() - 1000 * 60 * 60).toISOString()
      }
    },
    reviews: {
      rating: 4.4,
      totalReviews: 5621,
      breakdown: { 5: 3247, 4: 1456, 3: 623, 2: 201, 1: 94 }
    },
    priceHistory: [
      { date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 30).toISOString(), price: 1199.99 },
      { date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 15).toISOString(), price: 1149.99 },
      { date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString(), price: 1249.99 }
    ],
    alerts: {
      priceTarget: 1100.00,
      stockAlert: true,
      priceDropAlert: true
    },
    image: 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=300&h=300&fit=crop',
    dateAdded: new Date(Date.now() - 1000 * 60 * 60 * 24 * 30).toISOString()
  }
];

export const ProductProvider = ({ children }) => {
  const [products, setProducts] = useState([]);
  const [priceAlerts, setPriceAlerts] = useState([]);

  useEffect(() => {
    const savedProducts = localStorage.getItem('priceTracker_products');
    const savedAlerts = localStorage.getItem('priceTracker_alerts');
    
    if (savedProducts) {
      try {
        setProducts(JSON.parse(savedProducts));
      } catch (error) {
        console.error('Error parsing saved products:', error);
        setProducts(mockProducts);
      }
    } else {
      setProducts(mockProducts);
    }

    if (savedAlerts) {
      try {
        setPriceAlerts(JSON.parse(savedAlerts));
      } catch (error) {
        console.error('Error parsing saved alerts:', error);
        setPriceAlerts([]);
      }
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('priceTracker_products', JSON.stringify(products));
    } catch (error) {
      console.error('Error saving products:', error);
    }
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem('priceTracker_alerts', JSON.stringify(priceAlerts));
    } catch (error) {
      console.error('Error saving alerts:', error);
    }
  }, [priceAlerts]);

  const addProducts = (urls) => {
    const newProducts = urls.map((url, index) => {
      const mockNames = [
        'MacBook Pro 14" M3 Chip',
        'Nike Air Max 270 Sneakers', 
        'KitchenAid Stand Mixer',
        'Dyson V15 Detect Vacuum',
        'Apple Watch Series 9',
        'PlayStation 5 Console',
        'Canon EOS R6 Camera',
        'Instant Pot Duo 7-in-1'
      ];

      const mockBrands = ['Apple', 'Nike', 'KitchenAid', 'Dyson', 'Sony', 'Canon', 'Instant Pot'];
      const mockCategories = ['Electronics', 'Fashion', 'Home & Kitchen', 'Gaming', 'Photography'];
      const mockStores = ['Amazon', 'Best Buy', 'Target', 'Walmart', 'eBay'];
      const mockImages = [
        'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=300&fit=crop',
        'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=300&h=300&fit=crop'
      ];

      const basePrice = Math.floor(Math.random() * 1000) + 100;
      const name = mockNames[Math.floor(Math.random() * mockNames.length)];
      const brand = mockBrands[Math.floor(Math.random() * mockBrands.length)];
      
      // Generate store data
      const stores = {};
      const selectedStores = mockStores.slice(0, Math.floor(Math.random() * 3) + 2);
      
      selectedStores.forEach(store => {
        const priceVariation = (Math.random() - 0.5) * 100;
        const currentPrice = basePrice + priceVariation;
        const availabilityRand = Math.random();
        
        stores[store] = {
          price: currentPrice > 0 ? currentPrice : 0,
          originalPrice: basePrice,
          availability: currentPrice === 0 ? 'Out of Stock' : 
                       availabilityRand > 0.8 ? 'Limited Stock' : 'In Stock',
          quantity: currentPrice === 0 ? 0 : Math.floor(Math.random() * 50) + 1,
          seller: store,
          shipping: store === 'Amazon' ? 'Free 2-day shipping' : 'Standard shipping',
          lastUpdated: new Date(Date.now() - Math.random() * 1000 * 60 * 60).toISOString()
        };
      });

      return {
        id: Date.now().toString() + index,
        name,
        url,
        brand,
        category: mockCategories[Math.floor(Math.random() * mockCategories.length)],
        description: `High-quality ${name.toLowerCase()} with premium features and excellent performance`,
        stores,
        reviews: {
          rating: Math.round((Math.random() * 2 + 3) * 10) / 10,
          totalReviews: Math.floor(Math.random() * 10000) + 100,
          breakdown: {
            5: Math.floor(Math.random() * 5000) + 1000,
            4: Math.floor(Math.random() * 2000) + 500,
            3: Math.floor(Math.random() * 1000) + 200,
            2: Math.floor(Math.random() * 500) + 50,
            1: Math.floor(Math.random() * 200) + 10
          }
        },
        priceHistory: [
          { date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7).toISOString(), price: basePrice },
          { date: new Date().toISOString(), price: basePrice + (Math.random() - 0.5) * 50 }
        ],
        alerts: {
          priceTarget: basePrice * 0.85,
          stockAlert: true,
          priceDropAlert: true
        },
        image: mockImages[Math.floor(Math.random() * mockImages.length)],
        dateAdded: new Date().toISOString()
      };
    });

    setProducts(prevProducts => [...prevProducts, ...newProducts]);
  };

  const removeProduct = (productId) => {
    setProducts(prevProducts => prevProducts.filter(p => p.id !== productId));
  };

  const updateProductAlerts = (productId, alerts) => {
    setProducts(prevProducts => 
      prevProducts.map(product => 
        product.id === productId 
          ? { ...product, alerts: { ...product.alerts, ...alerts } }
          : product
      )
    );
  };

  const checkPriceAlerts = () => {
    const newAlerts = [];
    
    products.forEach(product => {
      const lowestPrice = Math.min(...Object.values(product.stores)
        .filter(store => store.availability !== 'Out of Stock')
        .map(store => store.price));
      
      if (product.alerts.priceTarget && lowestPrice <= product.alerts.priceTarget) {
        newAlerts.push({
          id: Date.now().toString() + Math.random(),
          productId: product.id,
          productName: product.name,
          type: 'price_target',
          message: `${product.name} has reached your target price of $${product.alerts.priceTarget}!`,
          currentPrice: lowestPrice,
          targetPrice: product.alerts.priceTarget,
          timestamp: new Date().toISOString()
        });
      }

      // Check for back in stock alerts
      Object.entries(product.stores).forEach(([storeName, store]) => {
        if (store.availability === 'In Stock' && product.alerts.stockAlert) {
          // This would normally check against previous availability status
          const wasOutOfStock = Math.random() > 0.8; // Simulate previous out of stock
          if (wasOutOfStock) {
            newAlerts.push({
              id: Date.now().toString() + Math.random(),
              productId: product.id,
              productName: product.name,
              type: 'back_in_stock',
              message: `${product.name} is back in stock at ${storeName}!`,
              store: storeName,
              price: store.price,
              timestamp: new Date().toISOString()
            });
          }
        }
      });
    });

    if (newAlerts.length > 0) {
      setPriceAlerts(prevAlerts => [...prevAlerts, ...newAlerts]);
    }
  };

  const dismissAlert = (alertId) => {
    setPriceAlerts(prevAlerts => prevAlerts.filter(alert => alert.id !== alertId));
  };

  const exportToCSV = () => {
    try {
      const csvData = [];
      
      products.forEach(product => {
        Object.entries(product.stores).forEach(([storeName, store]) => {
          csvData.push({
            'Product Name': product.name,
            'Brand': product.brand,
            'Category': product.category,
            'Store': storeName,
            'Current Price': store.price > 0 ? `$${store.price.toFixed(2)}` : 'Out of Stock',
            'Original Price': `$${store.originalPrice.toFixed(2)}`,
            'Availability': store.availability,
            'Quantity': store.quantity,
            'Rating': product.reviews.rating,
            'Total Reviews': product.reviews.totalReviews,
            'Last Updated': new Date(store.lastUpdated).toLocaleString(),
            'URL': product.url
          });
        });
      });

      const csv = Papa.unparse(csvData);
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      
      link.setAttribute('href', url);
      link.setAttribute('download', `price-tracker-detailed-${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting CSV:', error);
      alert('Failed to export CSV. Please try again.');
    }
  };

  const value = {
    products,
    priceAlerts,
    addProducts,
    removeProduct,
    updateProductAlerts,
    checkPriceAlerts,
    dismissAlert,
    exportToCSV
  };

  return (
    <ProductContext.Provider value={value}>
      {children}
    </ProductContext.Provider>
  );
};