import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Analytics from './components/Analytics';
import PriceAlerts from './components/PriceAlerts';
import AddProduct from './components/AddProduct';
import Instructions from './components/Instructions';
import { ProductProvider } from './context/ProductContext';
import './App.css';

function App() {
  return (
    <ProductProvider>
      <Router>
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
          <Header />
          <main className="container mx-auto px-4 py-8">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/analytics" element={<Analytics />} />
              <Route path="/alerts" element={<PriceAlerts />} />
              <Route path="/add" element={<AddProduct />} />
              <Route path="/instructions" element={<Instructions />} />
            </Routes>
          </main>
        </div>
      </Router>
    </ProductProvider>
  );
}

export default App;