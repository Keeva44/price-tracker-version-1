import React, { useContext } from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import { ProductContext } from '../context/ProductContext';

const { FiX, FiStar, FiTrendingUp, FiTrendingDown, FiBell, FiTarget, FiExternalLink, FiShoppingCart, FiPackage } = FiIcons;

const ProductDetails = ({ product, onClose }) => {
  const { updateProductAlerts } = useContext(ProductContext);

  const formatPrice = (price) => {
    if (!price || isNaN(price)) return 'N/A';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(price);
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 0; i < 5; i++) {
      if (i < fullStars) {
        stars.push(<SafeIcon key={i} icon={FiStar} className="text-yellow-400 fill-current text-lg" />);
      } else if (i === fullStars && hasHalfStar) {
        stars.push(<SafeIcon key={i} icon={FiStar} className="text-yellow-400 fill-current opacity-50 text-lg" />);
      } else {
        stars.push(<SafeIcon key={i} icon={FiStar} className="text-gray-300 text-lg" />);
      }
    }
    return stars;
  };

  const getBestPrice = () => {
    const availableStores = Object.values(product.stores).filter(store => 
      store.availability !== 'Out of Stock' && store.price > 0
    );
    if (availableStores.length === 0) return null;
    return Math.min(...availableStores.map(store => store.price));
  };

  const getWorstPrice = () => {
    const availableStores = Object.values(product.stores).filter(store => 
      store.availability !== 'Out of Stock' && store.price > 0
    );
    if (availableStores.length === 0) return null;
    return Math.max(...availableStores.map(store => store.price));
  };

  const bestPrice = getBestPrice();
  const worstPrice = getWorstPrice();
  const priceDifference = bestPrice && worstPrice ? worstPrice - bestPrice : 0;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6">
          {/* Header */}
          <div className="flex items-start justify-between mb-6">
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">{product.name}</h2>
              <p className="text-gray-600 mb-4">{product.description}</p>
              <div className="flex items-center space-x-4 text-sm text-gray-500">
                <span>Brand: <strong>{product.brand}</strong></span>
                <span>Category: <strong>{product.category}</strong></span>
                <span>Added: {format(new Date(product.dateAdded), 'MMM dd, yyyy')}</span>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <SafeIcon icon={FiX} className="text-2xl" />
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left Column */}
            <div className="space-y-6">
              {/* Product Image */}
              <div className="aspect-square rounded-lg overflow-hidden bg-gray-100">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.target.src = 'https://via.placeholder.com/400x400?text=Product';
                  }}
                />
              </div>

              {/* Reviews Section */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-3">Customer Reviews</h3>
                <div className="flex items-center space-x-2 mb-4">
                  <div className="flex">
                    {renderStars(product.reviews.rating)}
                  </div>
                  <span className="text-xl font-bold">{product.reviews.rating}</span>
                  <span className="text-gray-500">
                    ({product.reviews.totalReviews.toLocaleString()} reviews)
                  </span>
                </div>
                
                {/* Rating Breakdown */}
                <div className="space-y-2">
                  {[5, 4, 3, 2, 1].map((star) => {
                    const count = product.reviews.breakdown[star];
                    const percentage = (count / product.reviews.totalReviews) * 100;
                    return (
                      <div key={star} className="flex items-center space-x-2 text-sm">
                        <span className="w-8">{star}★</span>
                        <div className="flex-1 bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-yellow-400 h-2 rounded-full"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                        <span className="w-12 text-right">{count.toLocaleString()}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Right Column */}
            <div className="space-y-6">
              {/* Price Summary */}
              <div className="bg-blue-50 rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-3">Price Summary</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">Best Price</p>
                    <p className="text-2xl font-bold text-green-600">
                      {bestPrice ? formatPrice(bestPrice) : 'Out of Stock'}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Highest Price</p>
                    <p className="text-2xl font-bold text-red-600">
                      {worstPrice ? formatPrice(worstPrice) : 'N/A'}
                    </p>
                  </div>
                </div>
                {priceDifference > 0 && (
                  <div className="mt-3 p-2 bg-yellow-100 rounded text-sm">
                    💡 You can save <strong>{formatPrice(priceDifference)}</strong> by choosing the best store!
                  </div>
                )}
              </div>

              {/* Store Prices */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Store Comparison</h3>
                <div className="space-y-3">
                  {Object.entries(product.stores)
                    .sort(([,a], [,b]) => {
                      if (a.availability === 'Out of Stock') return 1;
                      if (b.availability === 'Out of Stock') return -1;
                      return a.price - b.price;
                    })
                    .map(([storeName, store]) => (
                    <div
                      key={storeName}
                      className={`p-4 rounded-lg border ${
                        store.availability === 'Out of Stock' 
                          ? 'bg-gray-50 border-gray-200' 
                          : store.price === bestPrice 
                          ? 'bg-green-50 border-green-200' 
                          : 'bg-white border-gray-200'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">{storeName}</h4>
                          <p className="text-sm text-gray-600">{store.seller}</p>
                        </div>
                        <div className="text-right">
                          {store.availability === 'Out of Stock' ? (
                            <span className="text-red-600 font-medium">Out of Stock</span>
                          ) : (
                            <>
                              <div className="text-lg font-bold">
                                {formatPrice(store.price)}
                                {store.price === bestPrice && (
                                  <span className="text-green-600 text-sm ml-2">Best Deal!</span>
                                )}
                              </div>
                              {store.originalPrice > store.price && (
                                <div className="text-sm text-gray-500 line-through">
                                  {formatPrice(store.originalPrice)}
                                </div>
                              )}
                            </>
                          )}
                        </div>
                      </div>
                      <div className="mt-2 flex items-center justify-between text-sm text-gray-600">
                        <span className={`px-2 py-1 rounded text-xs ${
                          store.availability === 'In Stock' 
                            ? 'bg-green-100 text-green-800'
                            : store.availability === 'Limited Stock'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {store.availability}
                          {store.quantity > 0 && ` (${store.quantity} left)`}
                        </span>
                        <span>{store.shipping}</span>
                      </div>
                      <div className="text-xs text-gray-500 mt-1">
                        Updated {format(new Date(store.lastUpdated), 'MMM dd, HH:mm')}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Price Alerts */}
              <div className="bg-yellow-50 rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-3 flex items-center">
                  <SafeIcon icon={FiBell} className="mr-2" />
                  Price Alerts
                </h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Target Price
                    </label>
                    <div className="flex items-center space-x-2">
                      <input
                        type="number"
                        step="0.01"
                        defaultValue={product.alerts.priceTarget}
                        className="flex-1 border border-gray-300 rounded px-3 py-2 text-sm"
                        placeholder="Enter target price"
                      />
                      <button className="bg-primary-500 text-white px-4 py-2 rounded text-sm hover:bg-primary-600">
                        Set Alert
                      </button>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Stock Alerts</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        defaultChecked={product.alerts.stockAlert}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="flex space-x-3">
                <a
                  href={product.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 bg-primary-500 text-white px-4 py-3 rounded-lg hover:bg-primary-600 transition-colors text-center font-medium flex items-center justify-center"
                >
                  <SafeIcon icon={FiExternalLink} className="mr-2" />
                  View Product
                </a>
                <button className="flex-1 bg-green-500 text-white px-4 py-3 rounded-lg hover:bg-green-600 transition-colors font-medium flex items-center justify-center">
                  <SafeIcon icon={FiShoppingCart} className="mr-2" />
                  Quick Buy
                </button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default ProductDetails;