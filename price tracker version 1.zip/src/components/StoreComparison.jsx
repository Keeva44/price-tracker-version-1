import React from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const { FiX, FiExternalLink, FiTruck, FiMapPin, FiClock, FiDollarSign } = FiIcons;

const StoreComparison = ({ product, onClose }) => {
  const formatPrice = (price) => {
    if (!price || isNaN(price)) return 'N/A';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(price);
  };

  const getBestPrice = () => {
    const availableStores = Object.values(product.stores).filter(store => 
      store.availability !== 'Out of Stock' && store.price > 0
    );
    if (availableStores.length === 0) return null;
    return Math.min(...availableStores.map(store => store.price));
  };

  const bestPrice = getBestPrice();

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6">
          {/* Header */}
          <div className="flex items-start justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Store Comparison</h2>
              <p className="text-gray-600">{product.name}</p>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <SafeIcon icon={FiX} className="text-2xl" />
            </button>
          </div>

          {/* Price Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-green-50 rounded-lg p-4 text-center">
              <SafeIcon icon={FiDollarSign} className="text-2xl text-green-600 mx-auto mb-2" />
              <p className="text-sm text-gray-600">Best Price</p>
              <p className="text-xl font-bold text-green-600">
                {bestPrice ? formatPrice(bestPrice) : 'Out of Stock'}
              </p>
            </div>
            <div className="bg-blue-50 rounded-lg p-4 text-center">
              <SafeIcon icon={FiMapPin} className="text-2xl text-blue-600 mx-auto mb-2" />
              <p className="text-sm text-gray-600">Available Stores</p>
              <p className="text-xl font-bold text-blue-600">
                {Object.values(product.stores).filter(s => s.availability !== 'Out of Stock').length}
              </p>
            </div>
            <div className="bg-purple-50 rounded-lg p-4 text-center">
              <SafeIcon icon={FiTruck} className="text-2xl text-purple-600 mx-auto mb-2" />
              <p className="text-sm text-gray-600">Free Shipping</p>
              <p className="text-xl font-bold text-purple-600">
                {Object.values(product.stores).filter(s => s.shipping.includes('Free')).length}
              </p>
            </div>
          </div>

          {/* Store Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Object.entries(product.stores)
              .sort(([,a], [,b]) => {
                if (a.availability === 'Out of Stock') return 1;
                if (b.availability === 'Out of Stock') return -1;
                return a.price - b.price;
              })
              .map(([storeName, store]) => (
              <motion.div
                key={storeName}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`border rounded-lg p-6 ${
                  store.availability === 'Out of Stock' 
                    ? 'bg-gray-50 border-gray-200' 
                    : store.price === bestPrice 
                    ? 'bg-green-50 border-green-300 shadow-md' 
                    : 'bg-white border-gray-200'
                }`}
              >
                {/* Store Header */}
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-bold">{storeName}</h3>
                    <p className="text-sm text-gray-600">{store.seller}</p>
                  </div>
                  {store.price === bestPrice && store.availability !== 'Out of Stock' && (
                    <span className="bg-green-100 text-green-800 text-xs font-semibold px-2 py-1 rounded-full">
                      Best Deal!
                    </span>
                  )}
                </div>

                {/* Price Information */}
                <div className="mb-4">
                  {store.availability === 'Out of Stock' ? (
                    <div className="text-center py-4">
                      <span className="text-red-600 font-bold text-lg">Out of Stock</span>
                    </div>
                  ) : (
                    <>
                      <div className="text-3xl font-bold text-gray-900 mb-1">
                        {formatPrice(store.price)}
                      </div>
                      {store.originalPrice > store.price && (
                        <div className="flex items-center space-x-2">
                          <span className="text-gray-500 line-through">
                            {formatPrice(store.originalPrice)}
                          </span>
                          <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded">
                            Save {formatPrice(store.originalPrice - store.price)}
                          </span>
                        </div>
                      )}
                    </>
                  )}
                </div>

                {/* Availability & Stock */}
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      store.availability === 'In Stock' 
                        ? 'bg-green-100 text-green-800'
                        : store.availability === 'Limited Stock'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {store.availability}
                    </span>
                    {store.quantity > 0 && (
                      <span className="text-sm text-gray-600">
                        {store.quantity} in stock
                      </span>
                    )}
                  </div>
                </div>

                {/* Shipping Information */}
                <div className="mb-4 p-3 bg-gray-50 rounded">
                  <div className="flex items-center space-x-2 mb-1">
                    <SafeIcon icon={FiTruck} className="text-gray-600" />
                    <span className="text-sm font-medium">Shipping</span>
                  </div>
                  <p className="text-sm text-gray-600">{store.shipping}</p>
                </div>

                {/* Last Updated */}
                <div className="flex items-center space-x-2 text-xs text-gray-500 mb-4">
                  <SafeIcon icon={FiClock} />
                  <span>Updated {format(new Date(store.lastUpdated), 'MMM dd, HH:mm')}</span>
                </div>

                {/* Action Button */}
                <div className="space-y-2">
                  {store.availability !== 'Out of Stock' ? (
                    <>
                      <a
                        href={product.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full bg-primary-500 text-white py-3 px-4 rounded-lg hover:bg-primary-600 transition-colors font-medium text-center flex items-center justify-center"
                      >
                        <SafeIcon icon={FiExternalLink} className="mr-2" />
                        Buy at {storeName}
                      </a>
                      {store.price === bestPrice && (
                        <p className="text-xs text-green-600 text-center font-medium">
                          💰 Lowest price available!
                        </p>
                      )}
                    </>
                  ) : (
                    <button
                      disabled
                      className="w-full bg-gray-300 text-gray-500 py-3 px-4 rounded-lg cursor-not-allowed font-medium"
                    >
                      Currently Unavailable
                    </button>
                  )}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Price History Note */}
          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <h4 className="font-medium text-blue-800 mb-2">💡 Shopping Tips</h4>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• Prices are updated automatically every few minutes</li>
              <li>• Set price alerts to get notified when prices drop</li>
              <li>• Compare shipping costs and delivery times before purchasing</li>
              <li>• Check store policies for returns and warranties</li>
            </ul>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default StoreComparison;