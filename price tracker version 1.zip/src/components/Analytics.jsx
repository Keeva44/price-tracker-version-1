import React, { useContext } from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import { ProductContext } from '../context/ProductContext';

const { FiTrendingUp, FiTrendingDown, FiDollarSign, FiShoppingCart, FiPercent, FiBarChart3 } = FiIcons;

const Analytics = () => {
  const { products } = useContext(ProductContext);

  const calculateAnalytics = () => {
    let totalProducts = products.length;
    let totalStores = 0;
    let totalSavings = 0;
    let averageRating = 0;
    let totalReviews = 0;
    let categoryBreakdown = {};
    let brandBreakdown = {};
    let priceRanges = { '0-50': 0, '50-200': 0, '200-500': 0, '500+': 0 };
    let availabilityStats = { inStock: 0, limited: 0, outOfStock: 0 };

    products.forEach(product => {
      // Store count
      totalStores += Object.keys(product.stores).length;

      // Savings calculation
      Object.values(product.stores).forEach(store => {
        if (store.originalPrice > store.price && store.price > 0) {
          totalSavings += (store.originalPrice - store.price);
        }
      });

      // Reviews
      totalReviews += product.reviews.totalReviews;
      averageRating += product.reviews.rating * product.reviews.totalReviews;

      // Category breakdown
      categoryBreakdown[product.category] = (categoryBreakdown[product.category] || 0) + 1;

      // Brand breakdown
      brandBreakdown[product.brand] = (brandBreakdown[product.brand] || 0) + 1;

      // Price ranges (best price)
      const bestPrice = Math.min(...Object.values(product.stores)
        .filter(store => store.availability !== 'Out of Stock' && store.price > 0)
        .map(store => store.price));
      
      if (bestPrice !== Infinity) {
        if (bestPrice <= 50) priceRanges['0-50']++;
        else if (bestPrice <= 200) priceRanges['50-200']++;
        else if (bestPrice <= 500) priceRanges['200-500']++;
        else priceRanges['500+']++;
      }

      // Availability stats
      const hasInStock = Object.values(product.stores).some(s => s.availability === 'In Stock');
      const hasLimited = Object.values(product.stores).some(s => s.availability === 'Limited Stock');
      
      if (hasInStock) availabilityStats.inStock++;
      else if (hasLimited) availabilityStats.limited++;
      else availabilityStats.outOfStock++;
    });

    averageRating = totalReviews > 0 ? averageRating / totalReviews : 0;

    return {
      totalProducts,
      totalStores,
      totalSavings,
      averageRating: Math.round(averageRating * 10) / 10,
      totalReviews,
      categoryBreakdown,
      brandBreakdown,
      priceRanges,
      availabilityStats,
      averageStoresPerProduct: totalProducts > 0 ? Math.round(totalStores / totalProducts * 10) / 10 : 0
    };
  };

  const analytics = calculateAnalytics();

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(price);
  };

  if (products.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center py-12"
      >
        <div className="bg-white rounded-lg shadow-lg p-8">
          <SafeIcon icon={FiBarChart3} className="text-6xl text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-600 mb-2">
            No Analytics Data
          </h3>
          <p className="text-gray-500 mb-6">
            Add some products to see detailed analytics and insights
          </p>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-lg p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm">Total Products</p>
              <p className="text-3xl font-bold">{analytics.totalProducts}</p>
              <p className="text-blue-100 text-xs mt-1">
                Across {analytics.totalStores} stores
              </p>
            </div>
            <SafeIcon icon={FiShoppingCart} className="text-3xl text-blue-200" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-br from-green-500 to-green-600 text-white rounded-lg p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm">Total Savings</p>
              <p className="text-3xl font-bold">{formatPrice(analytics.totalSavings)}</p>
              <p className="text-green-100 text-xs mt-1">
                From price drops
              </p>
            </div>
            <SafeIcon icon={FiDollarSign} className="text-3xl text-green-200" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-gradient-to-br from-yellow-500 to-yellow-600 text-white rounded-lg p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-yellow-100 text-sm">Average Rating</p>
              <p className="text-3xl font-bold">{analytics.averageRating}★</p>
              <p className="text-yellow-100 text-xs mt-1">
                {analytics.totalReviews.toLocaleString()} reviews
              </p>
            </div>
            <SafeIcon icon={FiTrendingUp} className="text-3xl text-yellow-200" />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-gradient-to-br from-purple-500 to-purple-600 text-white rounded-lg p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm">Stores per Product</p>
              <p className="text-3xl font-bold">{analytics.averageStoresPerProduct}</p>
              <p className="text-purple-100 text-xs mt-1">
                Average coverage
              </p>
            </div>
            <SafeIcon icon={FiPercent} className="text-3xl text-purple-200" />
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Category Breakdown */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white rounded-lg shadow-lg p-6"
        >
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <SafeIcon icon={FiBarChart3} className="mr-2 text-blue-500" />
            Products by Category
          </h3>
          <div className="space-y-3">
            {Object.entries(analytics.categoryBreakdown)
              .sort(([,a], [,b]) => b - a)
              .map(([category, count]) => {
                const percentage = (count / analytics.totalProducts) * 100;
                return (
                  <div key={category} className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">{category}</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-24 bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-500 h-2 rounded-full"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                      <span className="text-sm text-gray-600 w-8">{count}</span>
                    </div>
                  </div>
                );
              })}
          </div>
        </motion.div>

        {/* Brand Breakdown */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white rounded-lg shadow-lg p-6"
        >
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <SafeIcon icon={FiTrendingUp} className="mr-2 text-green-500" />
            Products by Brand
          </h3>
          <div className="space-y-3">
            {Object.entries(analytics.brandBreakdown)
              .sort(([,a], [,b]) => b - a)
              .slice(0, 6)
              .map(([brand, count]) => {
                const percentage = (count / analytics.totalProducts) * 100;
                return (
                  <div key={brand} className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">{brand}</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-24 bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-green-500 h-2 rounded-full"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                      <span className="text-sm text-gray-600 w-8">{count}</span>
                    </div>
                  </div>
                );
              })}
          </div>
        </motion.div>

        {/* Price Range Distribution */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-white rounded-lg shadow-lg p-6"
        >
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <SafeIcon icon={FiDollarSign} className="mr-2 text-yellow-500" />
            Price Range Distribution
          </h3>
          <div className="space-y-3">
            {Object.entries(analytics.priceRanges).map(([range, count]) => {
              const percentage = analytics.totalProducts > 0 ? (count / analytics.totalProducts) * 100 : 0;
              return (
                <div key={range} className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-700">${range}</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-24 bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-yellow-500 h-2 rounded-full"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <span className="text-sm text-gray-600 w-8">{count}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>

        {/* Availability Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="bg-white rounded-lg shadow-lg p-6"
        >
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <SafeIcon icon={FiShoppingCart} className="mr-2 text-purple-500" />
            Availability Status
          </h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-sm font-medium text-gray-700">In Stock</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-24 bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-green-500 h-2 rounded-full"
                    style={{ width: `${analytics.totalProducts > 0 ? (analytics.availabilityStats.inStock / analytics.totalProducts) * 100 : 0}%` }}
                  />
                </div>
                <span className="text-sm text-gray-600 w-8">{analytics.availabilityStats.inStock}</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <span className="text-sm font-medium text-gray-700">Limited Stock</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-24 bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-yellow-500 h-2 rounded-full"
                    style={{ width: `${analytics.totalProducts > 0 ? (analytics.availabilityStats.limited / analytics.totalProducts) * 100 : 0}%` }}
                  />
                </div>
                <span className="text-sm text-gray-600 w-8">{analytics.availabilityStats.limited}</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <span className="text-sm font-medium text-gray-700">Out of Stock</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-24 bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-red-500 h-2 rounded-full"
                    style={{ width: `${analytics.totalProducts > 0 ? (analytics.availabilityStats.outOfStock / analytics.totalProducts) * 100 : 0}%` }}
                  />
                </div>
                <span className="text-sm text-gray-600 w-8">{analytics.availabilityStats.outOfStock}</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Insights */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg p-6"
      >
        <h3 className="text-xl font-bold mb-4">📊 Key Insights</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="bg-white bg-opacity-20 rounded-lg p-4">
            <h4 className="font-semibold mb-2">💰 Savings Opportunity</h4>
            <p className="text-sm">
              You've saved {formatPrice(analytics.totalSavings)} by tracking prices. 
              Keep monitoring for more deals!
            </p>
          </div>
          <div className="bg-white bg-opacity-20 rounded-lg p-4">
            <h4 className="font-semibold mb-2">🏪 Store Coverage</h4>
            <p className="text-sm">
              Average of {analytics.averageStoresPerProduct} stores per product. 
              More stores = better price comparison!
            </p>
          </div>
          <div className="bg-white bg-opacity-20 rounded-lg p-4">
            <h4 className="font-semibold mb-2">⭐ Quality Score</h4>
            <p className="text-sm">
              Your tracked products have an average rating of {analytics.averageRating}★ 
              based on {analytics.totalReviews.toLocaleString()} reviews.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Analytics;