import React, { useContext } from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import { ProductContext } from '../context/ProductContext';

const { FiPackage, FiTrendingDown, FiTrendingUp, FiDollarSign, FiShoppingCart, FiStar, FiBell } = FiIcons;

const StatsCards = () => {
  const { products, priceAlerts } = useContext(ProductContext);

  const calculateStats = () => {
    let totalProducts = products.length;
    let totalStores = 0;
    let inStockProducts = 0;
    let outOfStockProducts = 0;
    let totalSavings = 0;
    let averageRating = 0;
    let totalReviews = 0;
    let activeAlerts = priceAlerts.length;

    products.forEach(product => {
      totalStores += Object.keys(product.stores).length;
      
      // Check if product is available in any store
      const hasStock = Object.values(product.stores).some(store => 
        store.availability === 'In Stock' || store.availability === 'Limited Stock'
      );
      
      if (hasStock) {
        inStockProducts++;
      } else {
        outOfStockProducts++;
      }

      // Calculate savings
      Object.values(product.stores).forEach(store => {
        if (store.originalPrice > store.price && store.price > 0) {
          totalSavings += (store.originalPrice - store.price);
        }
      });

      // Reviews
      totalReviews += product.reviews.totalReviews;
      averageRating += product.reviews.rating * product.reviews.totalReviews;
    });

    averageRating = totalReviews > 0 ? averageRating / totalReviews : 0;

    return {
      totalProducts,
      totalStores,
      inStockProducts,
      outOfStockProducts,
      totalSavings,
      averageRating: Math.round(averageRating * 10) / 10,
      activeAlerts
    };
  };

  const stats = calculateStats();

  const cardData = [
    {
      title: 'Products Tracked',
      value: stats.totalProducts,
      subtitle: `Across ${stats.totalStores} stores`,
      icon: FiPackage,
      color: 'bg-blue-500',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-600'
    },
    {
      title: 'Total Savings',
      value: `$${stats.totalSavings.toFixed(2)}`,
      subtitle: 'From price drops',
      icon: FiDollarSign,
      color: 'bg-green-500',
      bgColor: 'bg-green-50',
      textColor: 'text-green-600'
    },
    {
      title: 'In Stock',
      value: stats.inStockProducts,
      subtitle: `${stats.outOfStockProducts} out of stock`,
      icon: FiShoppingCart,
      color: 'bg-emerald-500',
      bgColor: 'bg-emerald-50',
      textColor: 'text-emerald-600'
    },
    {
      title: 'Avg Rating',
      value: `${stats.averageRating}★`,
      subtitle: 'Customer satisfaction',
      icon: FiStar,
      color: 'bg-yellow-500',
      bgColor: 'bg-yellow-50',
      textColor: 'text-yellow-600'
    },
    {
      title: 'Price Alerts',
      value: stats.activeAlerts,
      subtitle: 'Active notifications',
      icon: FiBell,
      color: 'bg-purple-500',
      bgColor: 'bg-purple-50',
      textColor: 'text-purple-600'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
      {cardData.map((card, index) => (
        <motion.div
          key={card.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className={`${card.bgColor} rounded-lg p-6 border border-gray-200 hover:shadow-lg transition-shadow`}
        >
          <div className="flex items-center justify-between mb-4">
            <div className={`${card.color} p-3 rounded-lg`}>
              <SafeIcon icon={card.icon} className="text-white text-xl" />
            </div>
            {card.title === 'Price Alerts' && stats.activeAlerts > 0 && (
              <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded-full">
                {stats.activeAlerts} new
              </span>
            )}
          </div>
          
          <div>
            <p className="text-sm font-medium text-gray-600 mb-1">{card.title}</p>
            <p className={`text-2xl font-bold ${card.textColor} mb-1`}>{card.value}</p>
            <p className="text-xs text-gray-500">{card.subtitle}</p>
          </div>

          {/* Progress indicators for some cards */}
          {card.title === 'In Stock' && stats.totalProducts > 0 && (
            <div className="mt-3">
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-emerald-500 h-2 rounded-full transition-all"
                  style={{ width: `${(stats.inStockProducts / stats.totalProducts) * 100}%` }}
                />
              </div>
            </div>
          )}
        </motion.div>
      ))}
    </div>
  );
};

export default StatsCards;