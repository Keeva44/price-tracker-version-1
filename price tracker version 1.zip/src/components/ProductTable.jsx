import React, { useContext, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import { ProductContext } from '../context/ProductContext';
import ProductDetails from './ProductDetails';
import StoreComparison from './StoreComparison';

const { FiTrash2, FiExternalLink, FiEye, FiStar, FiTrendingUp, FiTrendingDown, FiMinus, FiShoppingCart, FiFilter } = FiIcons;

const ProductTable = () => {
  const { products, removeProduct } = useContext(ProductContext);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showStoreComparison, setShowStoreComparison] = useState(null);
  const [filterBy, setFilterBy] = useState('all');
  const [sortBy, setSortBy] = useState('name');

  if (products.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center py-12"
      >
        <div className="bg-white rounded-lg shadow-lg p-8">
          <SafeIcon icon={FiShoppingCart} className="text-6xl text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-600 mb-2">
            No Products Being Tracked
          </h3>
          <p className="text-gray-500 mb-6">
            Start by adding some products to track their prices across multiple stores
          </p>
        </div>
      </motion.div>
    );
  }

  const getBestPrice = (stores) => {
    const availableStores = Object.values(stores).filter(store => 
      store.availability !== 'Out of Stock' && store.price > 0
    );
    if (availableStores.length === 0) return null;
    return Math.min(...availableStores.map(store => store.price));
  };

  const getBestStore = (stores) => {
    const availableStores = Object.entries(stores).filter(([_, store]) => 
      store.availability !== 'Out of Stock' && store.price > 0
    );
    if (availableStores.length === 0) return null;
    return availableStores.reduce((best, [storeName, store]) => 
      store.price < best[1].price ? [storeName, store] : best
    );
  };

  const getOverallAvailability = (stores) => {
    const storeValues = Object.values(stores);
    const inStock = storeValues.filter(store => store.availability === 'In Stock').length;
    const limited = storeValues.filter(store => store.availability === 'Limited Stock').length;
    const total = storeValues.length;
    
    if (inStock > 0) return 'In Stock';
    if (limited > 0) return 'Limited Stock';
    return 'Out of Stock';
  };

  const filteredProducts = products.filter(product => {
    if (filterBy === 'all') return true;
    if (filterBy === 'in-stock') return getOverallAvailability(product.stores) !== 'Out of Stock';
    if (filterBy === 'out-of-stock') return getOverallAvailability(product.stores) === 'Out of Stock';
    if (filterBy === 'price-drops') {
      const bestPrice = getBestPrice(product.stores);
      const originalPrice = Object.values(product.stores)[0]?.originalPrice;
      return bestPrice && originalPrice && bestPrice < originalPrice;
    }
    return true;
  });

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case 'name':
        return a.name.localeCompare(b.name);
      case 'price':
        const priceA = getBestPrice(a.stores) || Infinity;
        const priceB = getBestPrice(b.stores) || Infinity;
        return priceA - priceB;
      case 'rating':
        return b.reviews.rating - a.reviews.rating;
      case 'added':
        return new Date(b.dateAdded) - new Date(a.dateAdded);
      default:
        return 0;
    }
  });

  const formatPrice = (price) => {
    if (!price || isNaN(price)) return 'N/A';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(price);
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 0; i < 5; i++) {
      if (i < fullStars) {
        stars.push(<SafeIcon key={i} icon={FiStar} className="text-yellow-400 fill-current" />);
      } else if (i === fullStars && hasHalfStar) {
        stars.push(<SafeIcon key={i} icon={FiStar} className="text-yellow-400 fill-current opacity-50" />);
      } else {
        stars.push(<SafeIcon key={i} icon={FiStar} className="text-gray-300" />);
      }
    }
    return stars;
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-white rounded-lg shadow-lg overflow-hidden"
      >
        {/* Filters and Sort */}
        <div className="p-4 border-b border-gray-200 bg-gray-50">
          <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
            <div className="flex items-center space-x-4">
              <SafeIcon icon={FiFilter} className="text-gray-500" />
              <select
                value={filterBy}
                onChange={(e) => setFilterBy(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500"
              >
                <option value="all">All Products</option>
                <option value="in-stock">In Stock</option>
                <option value="out-of-stock">Out of Stock</option>
                <option value="price-drops">Price Drops</option>
              </select>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary-500"
              >
                <option value="name">Sort by Name</option>
                <option value="price">Sort by Price</option>
                <option value="rating">Sort by Rating</option>
                <option value="added">Sort by Date Added</option>
              </select>
            </div>
            <div className="text-sm text-gray-600">
              Showing {sortedProducts.length} of {products.length} products
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Product Details
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Best Price
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Rating & Reviews
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Availability
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Stores
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {sortedProducts.map((product, index) => {
                const bestPrice = getBestPrice(product.stores);
                const bestStore = getBestStore(product.stores);
                const availability = getOverallAvailability(product.stores);
                const storeCount = Object.keys(product.stores).length;
                const inStockStores = Object.values(product.stores).filter(s => s.availability === 'In Stock').length;
                
                return (
                  <motion.tr
                    key={product.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="hover:bg-gray-50 transition-colors"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center">
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-16 h-16 rounded-lg object-cover mr-4 shadow-sm"
                          onError={(e) => {
                            e.target.src = 'https://via.placeholder.com/100x100?text=Product';
                          }}
                        />
                        <div>
                          <div className="text-sm font-medium text-gray-900 max-w-xs">
                            {product.name}
                          </div>
                          <div className="text-sm text-gray-500">
                            {product.brand} • {product.category}
                          </div>
                          <div className="text-xs text-gray-400 mt-1">
                            Added {format(new Date(product.dateAdded), 'MMM dd, yyyy')}
                          </div>
                        </div>
                      </div>
                    </td>
                    
                    <td className="px-6 py-4">
                      {bestPrice ? (
                        <div>
                          <div className="text-lg font-bold text-green-600">
                            {formatPrice(bestPrice)}
                          </div>
                          {bestStore && (
                            <div className="text-xs text-gray-500">
                              at {bestStore[0]}
                            </div>
                          )}
                          {bestStore && bestStore[1].originalPrice > bestPrice && (
                            <div className="text-xs text-gray-400 line-through">
                              {formatPrice(bestStore[1].originalPrice)}
                            </div>
                          )}
                        </div>
                      ) : (
                        <span className="text-red-500 font-medium">Out of Stock</span>
                      )}
                    </td>

                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-1 mb-1">
                        {renderStars(product.reviews.rating)}
                        <span className="text-sm font-medium text-gray-900 ml-2">
                          {product.reviews.rating}
                        </span>
                      </div>
                      <div className="text-xs text-gray-500">
                        {product.reviews.totalReviews.toLocaleString()} reviews
                      </div>
                    </td>

                    <td className="px-6 py-4">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        availability === 'In Stock'
                          ? 'bg-green-100 text-green-800'
                          : availability === 'Limited Stock'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {availability}
                      </span>
                      <div className="text-xs text-gray-500 mt-1">
                        {inStockStores}/{storeCount} stores
                      </div>
                    </td>

                    <td className="px-6 py-4">
                      <button
                        onClick={() => setShowStoreComparison(product.id)}
                        className="text-primary-600 hover:text-primary-800 text-sm font-medium"
                      >
                        View {storeCount} stores
                      </button>
                    </td>

                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => setSelectedProduct(product)}
                          className="text-blue-600 hover:text-blue-800 transition-colors"
                          title="View Details"
                        >
                          <SafeIcon icon={FiEye} className="text-lg" />
                        </button>
                        <a
                          href={product.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-primary-600 hover:text-primary-800 transition-colors"
                          title="Visit Product Page"
                        >
                          <SafeIcon icon={FiExternalLink} className="text-lg" />
                        </a>
                        <button
                          onClick={() => removeProduct(product.id)}
                          className="text-red-600 hover:text-red-800 transition-colors"
                          title="Remove Product"
                        >
                          <SafeIcon icon={FiTrash2} className="text-lg" />
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Product Details Modal */}
      <AnimatePresence>
        {selectedProduct && (
          <ProductDetails
            product={selectedProduct}
            onClose={() => setSelectedProduct(null)}
          />
        )}
      </AnimatePresence>

      {/* Store Comparison Modal */}
      <AnimatePresence>
        {showStoreComparison && (
          <StoreComparison
            product={products.find(p => p.id === showStoreComparison)}
            onClose={() => setShowStoreComparison(null)}
          />
        )}
      </AnimatePresence>
    </>
  );
};

export default ProductTable;