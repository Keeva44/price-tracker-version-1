import React, { useContext } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import ProductTable from './ProductTable';
import StatsCards from './StatsCards';
import { ProductContext } from '../context/ProductContext';

const { FiPlus, FiDownload } = FiIcons;

const Dashboard = () => {
  const { products, exportToCSV } = useContext(ProductContext);

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 className="text-4xl font-bold text-gray-800 mb-2">
          Price Tracking Dashboard
        </h1>
        <p className="text-gray-600 text-lg">
          Monitor your favorite products and never miss a deal
        </p>
      </motion.div>

      {/* Stats Cards */}
      <StatsCards />

      {/* Action Buttons */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="flex flex-col sm:flex-row gap-4 justify-center"
      >
        <Link
          to="/add"
          className="flex items-center justify-center space-x-2 bg-primary-500 text-white px-6 py-3 rounded-lg hover:bg-primary-600 transition-colors font-medium"
        >
          <SafeIcon icon={FiPlus} className="text-lg" />
          <span>Add New Product</span>
        </Link>
        
        {products.length > 0 && (
          <button
            onClick={exportToCSV}
            className="flex items-center justify-center space-x-2 bg-green-500 text-white px-6 py-3 rounded-lg hover:bg-green-600 transition-colors font-medium"
          >
            <SafeIcon icon={FiDownload} className="text-lg" />
            <span>Export to CSV</span>
          </button>
        )}
      </motion.div>

      {/* Products Table */}
      <ProductTable />
    </div>
  );
};

export default Dashboard;