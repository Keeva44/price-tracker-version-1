import React from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';

const { FiDownload, FiServer, FiGlobe, FiCode, FiSettings, FiMail } = FiIcons;

const Instructions = () => {
  const sections = [
    {
      title: "Getting Started",
      icon: FiGlobe,
      content: [
        "1. Clone or download the project files to your computer",
        "2. Install Node.js (version 16 or higher) from nodejs.org",
        "3. Open terminal/command prompt in the project folder",
        "4. Run 'npm install' to install dependencies",
        "5. Run 'npm run dev' to start the development server"
      ]
    },
    {
      title: "Adding Backend Functionality",
      icon: FiServer,
      content: [
        "1. Create a backend folder in your project",
        "2. Set up a Node.js/Express server or Python/Flask server",
        "3. Install web scraping libraries (Puppeteer for Node.js or BeautifulSoup for Python)",
        "4. Implement API endpoints for product scraping",
        "5. Connect the frontend to your backend API"
      ]
    },
    {
      title: "Deployment Options",
      icon: FiDownload,
      content: [
        "Frontend: Deploy to Netlify, Vercel, or GitHub Pages",
        "Backend: Deploy to Railway, Render, or PythonAnywhere",
        "Database: Use MongoDB Atlas or PostgreSQL on Railway",
        "For beginners: Use Replit for full-stack deployment",
        "Configure environment variables for production"
      ]
    },
    {
      title: "Backend Code Example (Node.js)",
      icon: FiCode,
      content: [
        "// server.js",
        "const express = require('express');",
        "const puppeteer = require('puppeteer');",
        "const app = express();",
        "",
        "app.post('/api/scrape', async (req, res) => {",
        "  const { urls } = req.body;",
        "  const browser = await puppeteer.launch();",
        "  const results = [];",
        "  ",
        "  for (const url of urls) {",
        "    const page = await browser.newPage();",
        "    await page.goto(url);",
        "    ",
        "    const product = await page.evaluate(() => {",
        "      return {",
        "        name: document.querySelector('h1')?.textContent,",
        "        price: document.querySelector('.price')?.textContent,",
        "        availability: 'In Stock'",
        "      };",
        "    });",
        "    ",
        "    results.push({ ...product, url });",
        "  }",
        "  ",
        "  await browser.close();",
        "  res.json(results);",
        "});",
        "",
        "app.listen(3001);"
      ]
    },
    {
      title: "Scheduling Price Checks",
      icon: FiSettings,
      content: [
        "1. Use node-cron for Node.js scheduling",
        "2. Set up daily/hourly checks with cron.schedule()",
        "3. Store price history in a database",
        "4. Send email notifications using nodemailer",
        "5. Example: cron.schedule('0 9 * * *', () => checkPrices())"
      ]
    },
    {
      title: "Email Notifications",
      icon: FiMail,
      content: [
        "1. Install nodemailer: npm install nodemailer",
        "2. Set up email service (Gmail, SendGrid, etc.)",
        "3. Create email templates for price alerts",
        "4. Send notifications when prices drop",
        "5. Include CSV reports in email attachments"
      ]
    }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <h1 className="text-4xl font-bold text-gray-800 mb-2">
          Setup Instructions
        </h1>
        <p className="text-gray-600 text-lg">
          Complete guide to set up and deploy your price tracker
        </p>
      </motion.div>

      <div className="space-y-6">
        {sections.map((section, index) => (
          <motion.div
            key={section.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-lg shadow-lg p-6"
          >
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-primary-500 p-2 rounded-lg">
                <SafeIcon icon={section.icon} className="text-white text-xl" />
              </div>
              <h2 className="text-xl font-bold text-gray-800">{section.title}</h2>
            </div>
            
            <div className="space-y-2">
              {section.content.map((item, itemIndex) => (
                <div
                  key={itemIndex}
                  className={`${
                    item.startsWith('//') || item.includes('const') || item.includes('app.') || item.includes('await') || item.includes('});')
                      ? 'font-mono text-sm bg-gray-100 p-2 rounded border-l-4 border-blue-500'
                      : 'text-gray-700'
                  }`}
                >
                  {item}
                </div>
              ))}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Quick Start Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="bg-gradient-to-r from-primary-500 to-blue-600 rounded-lg shadow-lg p-6 text-white mt-8"
      >
        <h2 className="text-2xl font-bold mb-4">Quick Start for Non-Coders</h2>
        <div className="space-y-2">
          <p>1. Sign up for a free Replit account at replit.com</p>
          <p>2. Import this project or create a new Node.js repl</p>
          <p>3. Copy the project files to your repl</p>
          <p>4. Click "Run" to start your price tracker</p>
          <p>5. Your app will be live with a public URL!</p>
        </div>
      </motion.div>
    </div>
  );
};

export default Instructions;