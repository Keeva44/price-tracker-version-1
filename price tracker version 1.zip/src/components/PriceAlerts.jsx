import React, { useContext } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import { ProductContext } from '../context/ProductContext';

const { FiBell, FiX, FiTrendingDown, FiPackage, FiCheck, FiRefreshCw } = FiIcons;

const PriceAlerts = () => {
  const { priceAlerts, dismissAlert, checkPriceAlerts } = useContext(ProductContext);

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(price);
  };

  const getAlertIcon = (type) => {
    switch (type) {
      case 'price_target':
        return FiTrendingDown;
      case 'back_in_stock':
        return FiPackage;
      default:
        return FiBell;
    }
  };

  const getAlertColor = (type) => {
    switch (type) {
      case 'price_target':
        return 'text-green-600 bg-green-50 border-green-200';
      case 'back_in_stock':
        return 'text-blue-600 bg-blue-50 border-blue-200';
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Price Alerts</h1>
          <p className="text-gray-600 mt-1">
            Stay updated on price changes and stock availability
          </p>
        </div>
        <button
          onClick={checkPriceAlerts}
          className="flex items-center space-x-2 bg-primary-500 text-white px-4 py-2 rounded-lg hover:bg-primary-600 transition-colors"
        >
          <SafeIcon icon={FiRefreshCw} />
          <span>Check for Updates</span>
        </button>
      </div>

      {priceAlerts.length === 0 ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-12"
        >
          <div className="bg-white rounded-lg shadow-lg p-8">
            <SafeIcon icon={FiBell} className="text-6xl text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">
              No Active Alerts
            </h3>
            <p className="text-gray-500 mb-6">
              You'll see notifications here when prices drop or items come back in stock
            </p>
            <div className="bg-blue-50 rounded-lg p-4 text-sm text-blue-700">
              <p className="font-medium mb-2">💡 Tip:</p>
              <p>Set up price targets in your product details to get notified when prices reach your desired level!</p>
            </div>
          </div>
        </motion.div>
      ) : (
        <div className="space-y-4">
          <AnimatePresence>
            {priceAlerts.map((alert, index) => (
              <motion.div
                key={alert.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ delay: index * 0.1 }}
                className={`border rounded-lg p-4 ${getAlertColor(alert.type)}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    <div className="mt-1">
                      <SafeIcon icon={getAlertIcon(alert.type)} className="text-xl" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900 mb-1">
                        {alert.type === 'price_target' && '🎯 Price Target Reached!'}
                        {alert.type === 'back_in_stock' && '📦 Back in Stock!'}
                      </h3>
                      <p className="text-gray-700 mb-2">{alert.message}</p>
                      
                      {alert.type === 'price_target' && (
                        <div className="flex items-center space-x-4 text-sm">
                          <span>
                            <strong>Current:</strong> {formatPrice(alert.currentPrice)}
                          </span>
                          <span>
                            <strong>Target:</strong> {formatPrice(alert.targetPrice)}
                          </span>
                          <span className="text-green-600 font-medium">
                            💰 You save {formatPrice(alert.targetPrice - alert.currentPrice)}!
                          </span>
                        </div>
                      )}
                      
                      {alert.type === 'back_in_stock' && (
                        <div className="flex items-center space-x-4 text-sm">
                          <span>
                            <strong>Store:</strong> {alert.store}
                          </span>
                          <span>
                            <strong>Price:</strong> {formatPrice(alert.price)}
                          </span>
                        </div>
                      )}
                      
                      <div className="text-xs text-gray-500 mt-2">
                        {format(new Date(alert.timestamp), 'MMM dd, yyyy HH:mm')}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2 ml-4">
                    <button
                      onClick={() => dismissAlert(alert.id)}
                      className="text-gray-400 hover:text-gray-600 transition-colors"
                      title="Dismiss alert"
                    >
                      <SafeIcon icon={FiCheck} className="text-lg" />
                    </button>
                    <button
                      onClick={() => dismissAlert(alert.id)}
                      className="text-gray-400 hover:text-red-600 transition-colors"
                      title="Remove alert"
                    >
                      <SafeIcon icon={FiX} className="text-lg" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* Alert Settings */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-lg shadow-lg p-6"
      >
        <h3 className="text-lg font-semibold mb-4">Alert Settings</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-medium mb-3">Price Drop Alerts</h4>
            <div className="space-y-3">
              <label className="flex items-center">
                <input type="checkbox" defaultChecked className="mr-2" />
                <span className="text-sm">Notify when any price drops</span>
              </label>
              <label className="flex items-center">
                <input type="checkbox" defaultChecked className="mr-2" />
                <span className="text-sm">Notify when target price is reached</span>
              </label>
              <label className="flex items-center">
                <input type="checkbox" defaultChecked className="mr-2" />
                <span className="text-sm">Daily price summary email</span>
              </label>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium mb-3">Stock Alerts</h4>
            <div className="space-y-3">
              <label className="flex items-center">
                <input type="checkbox" defaultChecked className="mr-2" />
                <span className="text-sm">Notify when back in stock</span>
              </label>
              <label className="flex items-center">
                <input type="checkbox" className="mr-2" />
                <span className="text-sm">Notify when stock is low</span>
              </label>
              <label className="flex items-center">
                <input type="checkbox" className="mr-2" />
                <span className="text-sm">Weekly availability report</span>
              </label>
            </div>
          </div>
        </div>
        
        <div className="mt-6 pt-6 border-t border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">Email Notifications</h4>
              <p className="text-sm text-gray-600">Get alerts sent to your email address</p>
            </div>
            <div className="flex items-center space-x-3">
              <input
                type="email"
                placeholder="your.email@example.com"
                className="border border-gray-300 rounded px-3 py-2 text-sm"
              />
              <button className="bg-primary-500 text-white px-4 py-2 rounded text-sm hover:bg-primary-600">
                Save
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default PriceAlerts;