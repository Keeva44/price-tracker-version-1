import React, { useState, useContext } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import { ProductContext } from '../context/ProductContext';

const { FiPlus, FiTrash2, FiCheck, FiAlertCircle } = FiIcons;

const AddProduct = () => {
  const navigate = useNavigate();
  const { addProducts } = useContext(ProductContext);
  const [urls, setUrls] = useState(['']);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState([]);

  const addUrlField = () => {
    setUrls([...urls, '']);
  };

  const removeUrlField = (index) => {
    const newUrls = urls.filter((_, i) => i !== index);
    setUrls(newUrls.length > 0 ? newUrls : ['']);
  };

  const updateUrl = (index, value) => {
    const newUrls = [...urls];
    newUrls[index] = value;
    setUrls(newUrls);
  };

  const validateUrl = (url) => {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setErrors([]);

    const validUrls = urls.filter(url => url.trim() && validateUrl(url.trim()));
    const invalidUrls = urls.filter(url => url.trim() && !validateUrl(url.trim()));

    if (invalidUrls.length > 0) {
      setErrors(['Some URLs are invalid. Please check and try again.']);
      setIsLoading(false);
      return;
    }

    if (validUrls.length === 0) {
      setErrors(['Please enter at least one valid URL.']);
      setIsLoading(false);
      return;
    }

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Add products with mock data
      addProducts(validUrls);
      
      // Navigate back to dashboard
      navigate('/');
    } catch (error) {
      setErrors(['Failed to add products. Please try again.']);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-lg shadow-lg p-8"
      >
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">
            Add Products to Track
          </h1>
          <p className="text-gray-600">
            Enter product URLs from supported e-commerce websites
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* URL Input Fields */}
          <div className="space-y-4">
            <label className="block text-sm font-medium text-gray-700">
              Product URLs
            </label>
            
            {urls.map((url, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex space-x-2"
              >
                <input
                  type="url"
                  value={url}
                  onChange={(e) => updateUrl(index, e.target.value)}
                  placeholder="https://example.com/product-page"
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-colors"
                />
                {urls.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeUrlField(index)}
                    className="px-3 py-3 text-red-600 hover:text-red-800 transition-colors"
                  >
                    <SafeIcon icon={FiTrash2} className="text-lg" />
                  </button>
                )}
              </motion.div>
            ))}
          </div>

          {/* Add URL Button */}
          <button
            type="button"
            onClick={addUrlField}
            className="flex items-center space-x-2 text-primary-600 hover:text-primary-800 transition-colors"
          >
            <SafeIcon icon={FiPlus} className="text-lg" />
            <span>Add another URL</span>
          </button>

          {/* Error Messages */}
          {errors.length > 0 && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-center space-x-2 text-red-800">
                <SafeIcon icon={FiAlertCircle} className="text-lg" />
                <span className="font-medium">Errors:</span>
              </div>
              <ul className="mt-2 text-sm text-red-700 list-disc list-inside">
                {errors.map((error, index) => (
                  <li key={index}>{error}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Supported Sites Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="font-medium text-blue-800 mb-2">Supported Websites:</h3>
            <p className="text-sm text-blue-700">
              Amazon, eBay, Best Buy, Target, Walmart, and many more e-commerce sites.
              The app will automatically detect product information from the URL.
            </p>
          </div>

          {/* Submit Button */}
          <div className="flex space-x-4">
            <button
              type="submit"
              disabled={isLoading}
              className="flex-1 flex items-center justify-center space-x-2 bg-primary-500 text-white px-6 py-3 rounded-lg hover:bg-primary-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium"
            >
              {isLoading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <SafeIcon icon={FiCheck} className="text-lg" />
                  <span>Start Tracking</span>
                </>
              )}
            </button>
            
            <button
              type="button"
              onClick={() => navigate('/')}
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              Cancel
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default AddProduct;