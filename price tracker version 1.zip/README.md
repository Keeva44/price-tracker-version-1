# PriceTrackerOnline.com

A modern, responsive web application for tracking product prices from e-commerce websites. Built with React, Tailwind CSS, and designed for easy deployment.

## Features

- **Modern UI**: Clean, responsive design that works on all devices
- **Product Tracking**: Add multiple product URLs and track their prices
- **Price History**: Monitor price changes with visual indicators
- **Export Data**: Download tracking results as CSV files
- **Real-time Updates**: Check prices automatically (with backend)
- **Availability Monitoring**: Track product stock status

## Quick Start

### For Non-Coders (Easiest Method)

1. **Using Replit** (Recommended):
   - Go to [replit.com](https://replit.com) and create a free account
   - Click "Create Repl" and select "Import from GitHub"
   - Paste this repository URL
   - Click "Run" to start the application
   - Your app will be live with a public URL!

2. **Using CodeSandbox**:
   - Go to [codesandbox.io](https://codesandbox.io)
   - Click "Import from GitHub"
   - Paste this repository URL
   - The app will automatically start

### For Developers

#### Prerequisites
- Node.js (version 16 or higher)
- npm or yarn package manager

#### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd price-tracker-online
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and navigate to `http://localhost:5173`

## Backend Setup (Optional)

The current version runs with mock data. To add real price scraping functionality:

### Node.js Backend

1. Create a new folder called `backend` in your project
2. Initialize a new Node.js project:
```bash
cd backend
npm init -y
npm install express puppeteer cors
```

3. Create `server.js`:
```javascript
const express = require('express');
const puppeteer = require('puppeteer');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

app.post('/api/scrape', async (req, res) => {
  const { urls } = req.body;
  const browser = await puppeteer.launch({ headless: true });
  const results = [];

  for (const url of urls) {
    try {
      const page = await browser.newPage();
      await page.goto(url, { waitUntil: 'networkidle2' });

      const product = await page.evaluate(() => {
        // Generic selectors - customize for specific sites
        const name = document.querySelector('h1, [data-testid="product-title"], .product-title')?.textContent?.trim();
        const priceElement = document.querySelector('[data-testid="price"], .price, .a-price-whole, .sr-only');
        const price = priceElement?.textContent?.replace(/[^0-9.]/g, '');
        
        return {
          name: name || 'Product Name Not Found',
          price: price ? parseFloat(price) : 0,
          availability: 'In Stock' // Customize based on site
        };
      });

      results.push({ ...product, url });
      await page.close();
    } catch (error) {
      console.error(`Error scraping ${url}:`, error);
      results.push({
        name: 'Error loading product',
        price: 0,
        availability: 'Unknown',
        url,
        error: error.message
      });
    }
  }

  await browser.close();
  res.json(results);
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
```

4. Update the frontend API calls in `src/context/ProductContext.jsx` to use your backend

### Python Backend (Alternative)

1. Create `backend/app.py`:
```python
from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
from bs4 import BeautifulSoup
import re

app = Flask(__name__)
CORS(app)

@app.route('/api/scrape', methods=['POST'])
def scrape_products():
    urls = request.json.get('urls', [])
    results = []
    
    for url in urls:
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            response = requests.get(url, headers=headers)
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Generic selectors - customize for specific sites
            name = soup.find('h1') or soup.find('[data-testid="product-title"]')
            price_element = soup.find(class_=re.compile(r'price|cost'))
            
            name_text = name.get_text().strip() if name else 'Product Name Not Found'
            price_text = price_element.get_text() if price_element else '0'
            price = float(re.sub(r'[^0-9.]', '', price_text)) if price_text else 0
            
            results.append({
                'name': name_text,
                'price': price,
                'availability': 'In Stock',
                'url': url
            })
            
        except Exception as e:
            results.append({
                'name': 'Error loading product',
                'price': 0,
                'availability': 'Unknown',
                'url': url,
                'error': str(e)
            })
    
    return jsonify(results)

if __name__ == '__main__':
    app.run(debug=True, port=3001)
```

## Deployment Options

### Frontend Deployment

1. **Netlify** (Recommended):
   - Connect your GitHub repository to Netlify
   - Build command: `npm run build`
   - Publish directory: `dist`

2. **Vercel**:
   - Import your GitHub repository
   - Vercel auto-detects Vite configuration

3. **GitHub Pages**:
   - Enable GitHub Pages in repository settings
   - Use GitHub Actions for automatic deployment

### Backend Deployment

1. **Railway** (Recommended for Node.js):
   - Connect your GitHub repository
   - Railway auto-deploys your backend

2. **Render**:
   - Connect repository and select backend folder
   - Set start command: `node server.js`

3. **PythonAnywhere** (For Python backend):
   - Upload your Python files
   - Configure WSGI application

## Customization

### Adding New E-commerce Sites

1. Update the scraping selectors in your backend
2. Add site-specific logic for different product page structures
3. Handle different price formats and availability indicators

### Scheduling Price Checks

Add to your backend:
```javascript
const cron = require('node-cron');

// Check prices daily at 9 AM
cron.schedule('0 9 * * *', async () => {
  console.log('Running scheduled price check...');
  // Add your price checking logic here
});
```

### Email Notifications

```javascript
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransporter({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

const sendPriceAlert = (product, oldPrice, newPrice) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: 'user@example.com',
    subject: `Price Drop Alert: ${product.name}`,
    html: `
      <h2>Great news! The price dropped!</h2>
      <p><strong>${product.name}</strong></p>
      <p>Old Price: $${oldPrice}</p>
      <p>New Price: $${newPrice}</p>
      <p>You save: $${(oldPrice - newPrice).toFixed(2)}</p>
      <a href="${product.url}">View Product</a>
    `
  };

  transporter.sendMail(mailOptions);
};
```

## Environment Variables

Create a `.env` file in your backend directory:
```
PORT=3001
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-app-password
DATABASE_URL=your-database-url
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

MIT License - feel free to use this project for personal or commercial purposes.

## Support

For issues and questions:
- Check the Issues section of this repository
- Review the Instructions page in the app
- Consult the deployment guides for your chosen platform

## Technologies Used

- **Frontend**: React, Tailwind CSS, Framer Motion
- **Icons**: React Icons
- **Routing**: React Router
- **Data Export**: PapaParse
- **Build Tool**: Vite
- **Backend Options**: Node.js/Express or Python/Flask
- **Scraping**: Puppeteer (Node.js) or BeautifulSoup (Python)